for x in range(6, 12, 1):
    print(x)
print('Acabou!')