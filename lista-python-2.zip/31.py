for x in range(10, 2, -1):
    print(x)
print('Acabou!')