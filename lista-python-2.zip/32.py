for x in range(3, 19, 3):
    print(x)
print('Acabou!')