for x in range(100, -1, -5):
    print(x)
print('Acabou!')