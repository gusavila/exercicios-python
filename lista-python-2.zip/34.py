soma = 0

for x in range(6, 101, 2):
    soma += x
print('Soma = ', soma)