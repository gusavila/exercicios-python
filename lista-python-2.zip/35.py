soma = 0

for x in range(500, -1, -50):
    soma += x
print('Soma = ', soma)