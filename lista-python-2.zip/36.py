soma = 0
for x in range(0, 7):
    num = int(input('Digite o valor do numero: '))
    soma += num

print('Soma = ', soma)
