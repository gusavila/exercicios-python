nome = str(input('Qual o seu nome? '))
nome = nome + ','
print('Bem vindo',nome,', é um prazer te conhecer!')