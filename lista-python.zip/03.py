funcionario = str(input('Nome do funcionário:'))
slr = float(input('salário:'))
print('O funcionário', funcionario, 'tem um salário de ', slr, 'em Junho')