valor01 = float(input('Digite um valor: '))
valor02 = float(input('Digite outro valor: '))

print('A some entre', valor01 , 'e' , valor02 , 'é igual a' , valor01 + valor02)