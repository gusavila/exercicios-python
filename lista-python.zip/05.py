nota01 = float(input('Nota 01: '))
nota02 = float(input('Nota 02: '))

print('A média entre', nota01, 'e', nota02, 'é igual a ', (nota01 + nota02) / 2)