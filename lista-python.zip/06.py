num = int(input('Digite um número: '))

print('O antecessor de', num, 'é', num - 1, '\nO sucessor de', num, 'é', num+1)