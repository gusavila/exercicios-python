num = float(input('Digite um número: '))

print('O dobro de ', num, 'é', num + num, '\nA terça parte de', num, 'é', num / 3 )