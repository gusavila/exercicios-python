reais = float(input('Dinheiro(em R$) na carteira: '))
dolares = reais / 5.19
print('Você pode comprar', dolares,'dólares')