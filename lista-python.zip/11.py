preco = float(input('Digite o valor do produto: '))
precoPromocional = preco - ((preco * 5 ) / 100)

print('PREÇO PROMOCIONAL: ', precoPromocional)