salario = float(input('Digite o seu salário: '))
novoSalario = salario + ((salario * 15) / 100)

print('Novo salário: ', novoSalario)