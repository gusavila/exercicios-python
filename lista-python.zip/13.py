kmPercorridos = float(input('Digite a quantidade de Km percorridos: '))
qtdDias = int(input('Digite a quantidade de dias alugados:' ))
total = (qtdDias * 90) + (kmPercorridos * 0.20)
print('Preço total a pagar: ', total)