diasTrabalhados = int(input('Digite a quantidade de dias trabalhados: '))
salario = (diasTrabalhados * 8) * 25

print('Salário: ', salario)