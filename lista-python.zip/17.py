nota1 = float(input('Digite o valor da 1ª nota: '))
nota2 = float(input('Digite o valor da 2ª nota: '))

media = (nota1 + nota2) / 2

print('Media: ', media)

if(media >= 7):
    print('Você teve um bom aproveitamento!')
else:
    print('Você não teve um bom aproveitamento!')