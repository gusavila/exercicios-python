num = int(input('Digite um número: '))

if((num % 2) == 0):
    print('O valor é PAR!')
else:
    print('O valor é ÍMPAR!')